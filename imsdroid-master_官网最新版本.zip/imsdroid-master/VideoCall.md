## Supported Video Codecs ##
  * H.264 (Base Profile 1.0, 2.0 and 3.0)
  * MP4V-ES
  * Theora
  * H.263, H.263-1998, H.23-2000
  * H.261

## Full-Screen Mode ##
To enable the Full-Screen mode, go to "Options -> General" and check "Enable Full-Screen Video" checkbox.