## Supported Codecs ##
  * AMR-NB (Both Octet aligned and Bandwidth efficient)
  * GSM
  * PCMA and PCMU
  * Speex-NB
  * iLBC