html/installdox -l tinySAK.tag@http://doubango.org/android-ngn-stack html/*.html -l android-ngn-stack.tag@http://doubango.org/android-ngn-stack html/*.html
