package org.doubango.ngn.events;

/**
 * Created by dmi on 12/9/2016.
 */

public enum NgnNetworkEventTypes {
    CONNECTED,
    DISCONNECTED,
    CELLULAR_AVAILABLE,
}
