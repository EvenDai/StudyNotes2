

### Why the size of apk so important (~4Mo)? ###
The client contains both ARM5vTE and ARMv7-a binaries.

### Could I reuse the source code of IMSDroid in my application? ###
### Is there a library to develop a custom application?<br></h3>

### Could I register to any SIP server? ###
Yes. As far as your server is RFC 3261 compliant.
### How to lower registration 'Expires' value? ###

### Is iLBC supported? ###
Yes. But it's only available on ARMv7 (or later)devices.
### Is AMR supported? ###
Yes.
### Could I have G.729 codec? ###
G729AB is now supported. Because of licensing issue you have to rebuild the source code. <br />
For more information: http://code.google.com/p/imsdroid/wiki/Building_Source#Building_libtinyWRAP.so_with_G729AB
### Could I have EVRC codec? ###
### Could I make and receive calls on the emulator? ###
### How to call E.164 (e.g. tel:+33100000000) numbers? ###

### How to lower video CPU usage? ###